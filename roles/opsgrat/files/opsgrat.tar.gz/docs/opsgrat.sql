-- MySQL dump 10.13  Distrib 5.7.12, for osx10.11 (x86_64)
--
-- Host: localhost    Database: opsgrat
-- ------------------------------------------------------
-- Server version	5.7.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ansible_module`
--

DROP TABLE IF EXISTS `ansible_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ansible_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块名称',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT '显示权重(高的在前面)',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT '模块描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模块管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ansible_module`
--

LOCK TABLES `ansible_module` WRITE;
/*!40000 ALTER TABLE `ansible_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `ansible_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credential`
--

DROP TABLE IF EXISTS `credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '凭据名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '凭据类型：ssh-ssh；user_pwd-用户名密码；ansible_vault-Ansible Vault；aliyun_accesskey-阿里云AccessKey',
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `private_key` text COLLATE utf8mb4_unicode_ci COMMENT 'ssh私钥',
  `passphrase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ssh私钥密码',
  `become_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '切换方式:sudo；su；pbrun',
  `become_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '切换用户',
  `become_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '切换密码',
  `vault_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Vault密码',
  `vault_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Vault Id',
  `key_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Key Id',
  `key_secret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Key Secret',
  `cuser` varchar(150) NOT NULL DEFAULT '' COMMENT '创建用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='凭据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credential`
--

LOCK TABLES `credential` WRITE;
/*!40000 ALTER TABLE `credential` DISABLE KEYS */;
/*!40000 ALTER TABLE `credential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credential_team_permissions`
--

DROP TABLE IF EXISTS `credential_team_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credential_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT '0' COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '凭据id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_team_data_id` (`team_id`,`data_id`),
  KEY `credential_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='凭据团队权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credential_team_permissions`
--

LOCK TABLES `credential_team_permissions` WRITE;
/*!40000 ALTER TABLE `credential_team_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `credential_team_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credential_user_permissions`
--

DROP TABLE IF EXISTS `credential_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credential_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '' COMMENT '用户',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '凭据id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_user_data_id` (`username`,`data_id`),
  KEY `credential_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='凭据用户权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credential_user_permissions`
--

LOCK TABLES `credential_user_permissions` WRITE;
/*!40000 ALTER TABLE `credential_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `credential_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dingtalk_setting`
--

DROP TABLE IF EXISTS `dingtalk_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dingtalk_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `agent_id` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'AgentID',
  `corpid` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'CorpId',
  `corpsecret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'CorpSecret',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='钉钉设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dingtalk_setting`
--

LOCK TABLES `dingtalk_setting` WRITE;
/*!40000 ALTER TABLE `dingtalk_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `dingtalk_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_setting`
--

DROP TABLE IF EXISTS `email_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_host` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮件网关',
  `email_port` int(11) NOT NULL DEFAULT '465' COMMENT '邮件端口',
  `email_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `email_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `email_tls` int(11) NOT NULL DEFAULT '0' COMMENT '是否是tsl: 0-是，1-否',
  `email_ssl` int(11) NOT NULL DEFAULT '0' COMMENT '是否是ssh: 0-是，1-否',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮件设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_setting`
--

LOCK TABLES `email_setting` WRITE;
/*!40000 ALTER TABLE `email_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `environment_variable`
--

DROP TABLE IF EXISTS `environment_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `environment_variable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量名称',
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量值',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='环境变量管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `environment_variable`
--

LOCK TABLES `environment_variable` WRITE;
/*!40000 ALTER TABLE `environment_variable` DISABLE KEYS */;
/*!40000 ALTER TABLE `environment_variable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_group` (`inventory_id`,`name`),
  KEY `inventory_id` (`inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_children`
--

DROP TABLE IF EXISTS `group_children`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_children` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL COMMENT '组id',
  `child_id` int(11) DEFAULT NULL COMMENT '组id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_child` (`group_id`,`child_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='group关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_children`
--

LOCK TABLES `group_children` WRITE;
/*!40000 ALTER TABLE `group_children` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_children` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_hosts`
--

DROP TABLE IF EXISTS `group_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_hosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL COMMENT '组id',
  `host_id` int(11) DEFAULT NULL COMMENT '主机id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_host` (`group_id`,`host_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='group主机表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_hosts`
--

LOCK TABLES `group_hosts` WRITE;
/*!40000 ALTER TABLE `group_hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host`
--

DROP TABLE IF EXISTS `host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `host` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '主机名',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：1-启用；2-禁用',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_host` (`inventory_id`,`hostname`),
  KEY `inventory_id` (`inventory_id`),
  KEY `hostname` (`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host`
--

LOCK TABLES `host` WRITE;
/*!40000 ALTER TABLE `host` DISABLE KEYS */;
/*!40000 ALTER TABLE `host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_source`
--

DROP TABLE IF EXISTS `host_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `host_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'project' COMMENT '来源类型:project-自动化项目；restapi-Rest API；script-脚本；aliyun_ecs-阿里云ECS',
  `project_id` int(11) DEFAULT NULL COMMENT '自动化项目ID',
  `host_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '主机文件',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'API地址',
  `method` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '请求方式:get-GET;post-POST;put-PUT;patch-PATCH',
  `header` text COLLATE utf8mb4_unicode_ci COMMENT '头信息',
  `params` text COLLATE utf8mb4_unicode_ci COMMENT '参数模板',
  `source_script` text COLLATE utf8mb4_unicode_ci COMMENT '脚本内容',
  `credential_id` int(11) DEFAULT NULL COMMENT '凭据Id',
  `regions` text COLLATE utf8mb4_unicode_ci COMMENT '地域',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_source` (`inventory_id`),
  KEY `inventory_id` (`inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机来源表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_source`
--

LOCK TABLES `host_source` WRITE;
/*!40000 ALTER TABLE `host_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  `cuser` varchar(150) NOT NULL DEFAULT '' COMMENT '创建用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机清单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_team_permissions`
--

DROP TABLE IF EXISTS `inventory_team_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT '0' COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '主机清单id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_team_data_id` (`team_id`,`data_id`),
  KEY `inventory_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机清单团队权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_team_permissions`
--

LOCK TABLES `inventory_team_permissions` WRITE;
/*!40000 ALTER TABLE `inventory_team_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_team_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_user_permissions`
--

DROP TABLE IF EXISTS `inventory_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '' COMMENT '用户',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '主机清单id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_user_data_id` (`username`,`data_id`),
  KEY `inventory_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机清单用户权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_user_permissions`
--

LOCK TABLES `inventory_user_permissions` WRITE;
/*!40000 ALTER TABLE `inventory_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) DEFAULT NULL COMMENT '父任务ID',
  `kind` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'job' COMMENT '任务类型：job；workflow；command',
  `cuser` varchar(150) NOT NULL DEFAULT '' COMMENT '执行用户',
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `job_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'job类型:run-Run;check-Check',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `credential_id` int(11) DEFAULT NULL COMMENT '凭据id',
  `playbook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'playbook',
  `forks` int(11) NOT NULL DEFAULT '1' COMMENT 'forks',
  `limit` text COLLATE utf8mb4_unicode_ci COMMENT 'limit',
  `tags` text COLLATE utf8mb4_unicode_ci COMMENT 'tags',
  `skip_tags` text COLLATE utf8mb4_unicode_ci COMMENT 'skip tags',
  `verbosity` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Debug级别：0-Normal；1-Verbose；2-More Verbose；3-Debug；4-Connection Debug',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '扩展参数',
  `state` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new' COMMENT '运行结果：new-新建；waiting-等待中；running-运行中；successful-成功；failure-失败',
  `start_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `finish_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '完成时间',
  `inventory_str` mediumtext COLLATE utf8mb4_unicode_ci COMMENT 'inventory',
  `become_enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否允许切换用户:0-否；1-是',
  `diff_mode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用diff模块:0-否；1-是',
  `force_handlers` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否强制运行handlers任务:0-否；1-是',
  `start_at_task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开始任务',
  `module` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块',
  `arguments` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块参数',
  `node_id` int(11) DEFAULT NULL COMMENT '节点id',
  `schedule_id` int(11) DEFAULT NULL COMMENT '计划任务ID',
  `ctime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `project_id` int(11) DEFAULT NULL COMMENT '项目ID',
  PRIMARY KEY (`id`),
  KEY `finish_time` (`finish_time`),
  KEY `start_time` (`start_time`),
  KEY `inventory_id` (`inventory_id`),
  KEY `credential_id` (`credential_id`),
  KEY `job_id` (`job_id`),
  KEY `template_id` (`template_id`),
  KEY `cuser` (`cuser`),
  KEY `create_time` (`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_log`
--

DROP TABLE IF EXISTS `job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) DEFAULT NULL COMMENT '任务id',
  `ctime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `log` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '执行日志',
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_log`
--

LOCK TABLES `job_log` WRITE;
/*!40000 ALTER TABLE `job_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_settings`
--

DROP TABLE IF EXISTS `job_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workspace` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '工作目录',
  `job_timeout` int(11) NOT NULL DEFAULT '0' COMMENT '作业超时时间(秒)：0表示不超时',
  `idle_timeout` int(11) NOT NULL DEFAULT '0' COMMENT '作业无响应时间(秒)：0表示不超时',
  `keep_days` int(11) NOT NULL DEFAULT '180' COMMENT '日志保存天数(0表示不清理)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作任务设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_settings`
--

LOCK TABLES `job_settings` WRITE;
/*!40000 ALTER TABLE `job_settings` DISABLE KEYS */;
INSERT INTO `job_settings` VALUES (1,'/tmp',0,0,180);
/*!40000 ALTER TABLE `job_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '通知名称',
  `channel` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Alarm' COMMENT '渠道：WebHook-WebHook；Email-邮件；DingTalk-钉钉',
  `channel_id` int(11) DEFAULT NULL COMMENT '渠道ID',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `target_list` text COLLATE utf8mb4_unicode_ci COMMENT '通知目标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `repository_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '项目地址',
  `branch_specifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分支/Tag',
  `project_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '项目类型：git-Git项目；svn-svn项目；playbook-playbook',
  `playbook` text COLLATE utf8mb4_unicode_ci COMMENT 'playbook',
  `credential_id` int(11) DEFAULT NULL COMMENT '凭据ID',
  `revision` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Revision',
  `vault_credential_id` int(11) DEFAULT NULL COMMENT 'Vault凭据',
  `cuser` varchar(150) NOT NULL DEFAULT '' COMMENT '创建用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `credential_id` (`credential_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='自动化工程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_team_permissions`
--

DROP TABLE IF EXISTS `project_team_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT '0' COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '项目id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_team_data_id` (`team_id`,`data_id`),
  KEY `project_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目团队权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_team_permissions`
--

LOCK TABLES `project_team_permissions` WRITE;
/*!40000 ALTER TABLE `project_team_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_team_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_user_permissions`
--

DROP TABLE IF EXISTS `project_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '' COMMENT '用户',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '项目id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_user_data_id` (`username`,`data_id`),
  KEY `project_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目用户权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_user_permissions`
--

LOCK TABLES `project_user_permissions` WRITE;
/*!40000 ALTER TABLE `project_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qiye_weixin_settings`
--

DROP TABLE IF EXISTS `qiye_weixin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qiye_weixin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `agent_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Agent ID',
  `corpid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Corp ID',
  `corpsecret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Corp Secret',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='企业微信设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qiye_weixin_settings`
--

LOCK TABLES `qiye_weixin_settings` WRITE;
/*!40000 ALTER TABLE `qiye_weixin_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `qiye_weixin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '任务名称',
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cron' COMMENT '执行方式：cron-计划任务；interval-固定间隔；date-特定时间(只执行一次)',
  `start_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `cron_expr` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '计划任务表达式',
  `interval_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'seconds' COMMENT '间隔类型：seconds-秒；minutes-分钟；hours-小时；days-天；weeks-周',
  `interval` int(11) NOT NULL DEFAULT '0' COMMENT '间隔时间',
  `end_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `last_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后执行时间',
  `next_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '下次执行时间',
  `cuser` varchar(150) NOT NULL DEFAULT '' COMMENT '创建用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `start_time` (`start_time`),
  KEY `last_time` (`last_time`),
  KEY `next_time` (`next_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='计划任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_team_permissions`
--

DROP TABLE IF EXISTS `schedule_team_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT '0' COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '计划任务id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `schedule_team_data_id` (`team_id`,`data_id`),
  KEY `schedule_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='计划任务团队权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_team_permissions`
--

LOCK TABLES `schedule_team_permissions` WRITE;
/*!40000 ALTER TABLE `schedule_team_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_team_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_user_permissions`
--

DROP TABLE IF EXISTS `schedule_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '' COMMENT '用户',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '计划任务id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `schedule_user_data_id` (`username`,`data_id`),
  KEY `schedule_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='计划任务用户权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_user_permissions`
--

LOCK TABLES `schedule_user_permissions` WRITE;
/*!40000 ALTER TABLE `schedule_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'tag',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT '显示权重(高的在前面)',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT 'tag描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='tag管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '团队名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_users`
--

DROP TABLE IF EXISTS `team_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL COMMENT '团队id',
  `username` varchar(150) NOT NULL DEFAULT '' COMMENT '用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_user` (`team_id`,`username`),
  KEY `team_id` (`team_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队成员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_users`
--

LOCK TABLES `team_users` WRITE;
/*!40000 ALTER TABLE `team_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模板名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `template_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Job' COMMENT '模板类型:job-Job；workflow-Workflow',
  `job_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'job类型:run-Run;check-Check',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `project_id` int(11) DEFAULT NULL COMMENT '自动化工程id',
  `playbook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'playbook',
  `credential_id` int(11) DEFAULT NULL COMMENT '凭据id',
  `forks` int(11) NOT NULL DEFAULT '0' COMMENT 'forks',
  `limit` text COLLATE utf8mb4_unicode_ci COMMENT 'limit',
  `tags` text COLLATE utf8mb4_unicode_ci COMMENT 'tags',
  `skip_tags` text COLLATE utf8mb4_unicode_ci COMMENT 'skip tags',
  `verbosity` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Debug级别：0-Normal；1-Verbose；2-More Verbose；3-Debug；4-Connection Debug',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '扩展参数',
  `become_enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否允许切换用户:0-否；1-是',
  `diff_mode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用diff模块:0-否；1-是',
  `force_handlers` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否强制运行handlers任务:0-否；1-是',
  `start_at_task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开始任务',
  `cuser` varchar(150) NOT NULL DEFAULT '' COMMENT '创建用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `inventory_id` (`inventory_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='自动化模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_notification`
--

DROP TABLE IF EXISTS `template_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `notification_id` int(11) NOT NULL DEFAULT '0' COMMENT '通知id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_notification_id` (`template_id`,`notification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模板通知表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_notification`
--

LOCK TABLES `template_notification` WRITE;
/*!40000 ALTER TABLE `template_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_team_permissions`
--

DROP TABLE IF EXISTS `template_team_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT '0' COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '模板id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_team_data_id` (`team_id`,`data_id`),
  KEY `template_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模板团队权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_team_permissions`
--

LOCK TABLES `template_team_permissions` WRITE;
/*!40000 ALTER TABLE `template_team_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_team_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_user_permissions`
--

DROP TABLE IF EXISTS `template_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '' COMMENT '用户',
  `data_id` int(11) NOT NULL DEFAULT '0' COMMENT '模板id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_user_data_id` (`username`,`data_id`),
  KEY `template_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模板用户权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_user_permissions`
--

LOCK TABLES `template_user_permissions` WRITE;
/*!40000 ALTER TABLE `template_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_line`
--

DROP TABLE IF EXISTS `workflow_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `node_id` int(11) DEFAULT NULL COMMENT '节点ID',
  `next_node_id` int(11) DEFAULT NULL COMMENT '下个节点ID',
  `source_anchor` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '起始连线位置',
  `target_anchor` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '终止连线位置',
  `result` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'any' COMMENT '运行结果：any-任意；successful-成功；failure-失败',
  PRIMARY KEY (`id`),
  UNIQUE KEY `node_next_node` (`node_id`,`next_node_id`),
  KEY `node_id` (`node_id`),
  KEY `next_node_id` (`next_node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作流连线表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_line`
--

LOCK TABLES `workflow_line` WRITE;
/*!40000 ALTER TABLE `workflow_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_node`
--

DROP TABLE IF EXISTS `workflow_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '节点名称',
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `is_start_node` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开始节点：0-否；1-是',
  `left` int(11) NOT NULL COMMENT '距离左边位置',
  `top` int(11) NOT NULL COMMENT '距离顶部位置',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'template' COMMENT '节点类型: Template; Workflow',
  `bind_template_id` int(11) DEFAULT NULL COMMENT '绑定模板id',
  `forks` int(11) NOT NULL DEFAULT '0' COMMENT 'forks',
  `limit` text COLLATE utf8mb4_unicode_ci COMMENT 'limit',
  `tags` text COLLATE utf8mb4_unicode_ci COMMENT 'tags',
  `skip_tags` text COLLATE utf8mb4_unicode_ci COMMENT 'skip tags',
  `verbosity` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Debug级别：0-Normal；1-Verbose；2-More Verbose；3-Debug；4-Connection Debug',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '扩展参数',
  `become_enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否允许切换用户:0-否；1-是',
  `diff_mode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用diff模块:0-否；1-是',
  `force_handlers` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否强制运行handlers任务:0-否；1-是',
  `start_at_task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开始任务',
  `use_node_params` tinyint(3) NOT NULL DEFAULT '0' COMMENT '使用节点参数：0-否；1-是',
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `bind_template_id` (`bind_template_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作流节点表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_node`
--

LOCK TABLES `workflow_node` WRITE;
/*!40000 ALTER TABLE `workflow_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_node` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-21 14:18:37
