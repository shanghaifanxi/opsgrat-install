#!/bin/bash

read -p "Enter system user:" user
read -p "Enter http port:" port

path="/app/sso"

addUser() {
  egrep "^$user" /etc/passwd >& /dev/null
  if [ $? -ne 0 ]
  then
    useradd $user
  fi
}

installPkg() {
  sudo yum install python-devel mysql-devel mysql -y
  sudo yum install openldap openldap-devel -y
  sudo yum install gcc -y
  sudo pip install -r docs/requirements.txt
}

celeryDir() {
  sudo mkdir -p /var/log/celery
  sudo chown $user.$user /var/log/celery
  sudo mkdir -p /var/run/celery
  sudo chown $user.$user /var/run/celery
}

installPortal() {
  sudo pip install uwsgi
  sudo mkdir -p /var/log/sso
  sudo chown $user.$user /var/log/sso

  sudo sed -i "s/8001/$port/g" service.sh
  sudo sed -i "s/deploy/$user/g" service.sh

  sudo sed -i "s#/app/sso#$path#g" service.sh
  sudo cp service.sh /etc/init.d/sso
  sudo chmod +x /etc/init.d/sso


  sudo rm -fr $path
  sudo mkdir -p $path
  sudo cp -R * $path


}

installBeat() {
  sudo rm -f /etc/default/celerybeat
  sudo cp docs/default/celerybeat /etc/default
  sudo sed -i "s/deploy/$user/g" /etc/default/celerybeat

  sudo rm -f /etc/init.d/celerybeat
  sudo cp docs/init.d/celerybeat /etc/init.d
  sudo chmod +x /etc/init.d/celerybeat

  sudo sed -i "s#/app/sso#$path#g" /etc/default/celerybeat
}

installCeleryd() {
  sudo rm -f /etc/default/celeryd
  sudo cp docs/default/celeryd /etc/default
  sudo sed -i "s/deploy/$user/g" /etc/default/celeryd

  sudo rm -f /etc/init.d/celeryd
  sudo cp docs/init.d/celeryd /etc/init.d
  sudo chmod +x /etc/init.d/celeryd

  sudo sed -i "s#/app/sso#$path#g" /etc/default/celeryd
}

changeUser() {
  sudo chown -R $user.$user $path
}


case "$1" in
    all)
        addUser
        installPkg
        celeryDir
        installPortal
        installBeat
        installCeleryd
        changeUser
    ;;

    portal)
        addUser
        installPkg
        celeryDir
        installPortal
        changeUser
    ;;

    beat)
        addUser
        installPkg
        celeryDir
        installBeat
        changeUser
    ;;

    celeryd)
        addUser
        installPkg
        celeryDir
        installCeleryd
        changeUser
    ;;

    *)
        echo "Usage: sh ${SCRIPT_NAME} {all|portal|beat|celeryd}"
        exit 64  # EX_USAGE
    ;;
esac

exit 0
