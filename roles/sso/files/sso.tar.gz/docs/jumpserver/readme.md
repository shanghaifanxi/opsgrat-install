# jumpserver接入sso

## 步骤
1. 修改apps/config.py文件，在DevelopmentConfig类中加入sso认证地址和回调地址
```
class DevelopmentConfig(Config):
    DEBUG = True
    DB_ENGINE = 'mysql'
    DB_HOST = 'xxxxx'
    DB_PORT = 3306
    DB_USER = 'xxx'
    DB_PASSWORD = 'xxx'
    DB_NAME = 'jumpserver'

    # sso登录认证地址
    LOGIN_URL = "http://sso.fx.com:8001/sso/login/"

    # 获取sso已登录用户信息地址
    TOKEN_URL = "http://sso.fx.com:8001/api/sso/token/"

    # jumpserver给sso的回调用地址
    CALLBACK_URL = "http://127.0.0.1:8080/users/login/"


注：需要将上面的http://sso.fx.com:8001替换为sso的访问地址，http://127.0.0.1:8080替换为jumpserver的访问地址
```
2. 修改apps/jumpserver/settings.py文件将LOGIN_URL替换成带回调地址的sso认证地址
```
LOGIN_URL原内容如下：
LOGIN_URL = reverse_lazy('users:login')

LOGIN_URL新内容如下：
from urllib.parse import quote
LOGIN_URL = CONFIG.LOGIN_URL + "?redirect_url=" + quote(CONFIG.CALLBACK_URL)
```
3. 修改apps/users/views/login.py文件将UserLoginView类改造成可以根据sso的tokenKey获取登录用户信息并且执行登录，使用下面的代码替换UserLoginView类中的get方法
```
def get(self, request, *args, **kwargs):
        ############ 通过sso 302回调登录 ############
        import requests, json
        from config import config
        from django.http import HttpResponseRedirect
        tokenKey = request.GET.get('tokenKey')
        next = request.GET.get('next')
        if tokenKey:
            response = requests.get(config.TOKEN_URL + tokenKey + '/', params={}, headers={"Content-Type": "application/json"})
            if response.status_code == 200:
                userinfo = json.loads(response.text)
                user = User.objects.filter(username=userinfo.get('username')).first()
                if not user:
                    user = User(username=userinfo.get('username'), otp_level=0, _private_key='', _otp_secret_key='',
                                name=userinfo.get('last_name'), email=userinfo.get('email'), _public_key='')
                    user.save()
                auth_login(request, user)
                if next:
                    return HttpResponseRedirect(next)
                return HttpResponseRedirect("/")

        ############ 通过sso 302回调登录 ############
        if request.user.is_staff:
            return redirect(redirect_user_first_login_or_index(
                request, self.redirect_field_name)
            )
        request.session.set_test_cookie()
        return super().get(request, *args, **kwargs)
```
4. 改造apps/common/permissions.py文件，增加SSOMixin类并将AdminUserRequiredMixin类和SuperUserRequiredMixin类的父类替换成SSOMixin，这三个类修改后内容如下：
```
'''
302跳到sso登录认证页面
'''
class SSOMixin(UserPassesTestMixin):

    def dispatch(self, request, *args, **kwargs):
        from django.http import HttpResponseRedirect
        from config import config
        from urllib.parse import quote
        url = request.get_full_path()
        if not request.user.is_authenticated:
            login_url = config.LOGIN_URL + "?redirect_url=" + quote(config.CALLBACK_URL + "?next=" + quote(url))
            return HttpResponseRedirect(login_url)
        return super().dispatch(request, *args, **kwargs)

class AdminUserRequiredMixin(SSOMixin):
    def test_func(self):
        if not self.request.user.is_authenticated:
            return False
        elif not current_org.can_admin_by(self.request.user):
            self.raise_exception = True
            return False
        return True

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return super().dispatch(request, *args, **kwargs)

        if not current_org:
            return redirect('orgs:switch-a-org')

        if not current_org.can_admin_by(request.user):
            if request.user.is_org_admin:
                return redirect('orgs:switch-a-org')
            return HttpResponseForbidden()
        return super().dispatch(request, *args, **kwargs)


class SuperUserRequiredMixin(SSOMixin):
    def test_func(self):
        if self.request.user.is_authenticated and self.request.user.is_superuser:
            return True
```
5. 通过jms server端实现luna的单点登录，修改apps/users/views/login.py，在文件最后增加LunaLoginView类：
```
class LunaLoginView(LoginRequiredMixin, ListView):

    from django.utils.decorators import classonlymethod

    @classonlymethod
    def as_view(cls, **initkwargs):
        from functools import update_wrapper
        """Main entry point for a request-response process."""
        for key in initkwargs:
            if key in cls.http_method_names:
                raise TypeError("You tried to pass in the %s method name as a "
                                "keyword argument to %s(). Don't do that."
                                % (key, cls.__name__))
            if not hasattr(cls, key):
                raise TypeError("%s() received an invalid keyword %r. as_view "
                                "only accepts arguments that are already "
                                "attributes of the class." % (cls.__name__, key))

        def view(request, *args, **kwargs):
            from config import config as CONFIG
            from urllib.parse import quote
            from django.conf import settings
            hostname = request.GET.get('hostname', '')
            LOGIN_URL = CONFIG.LOGIN_URL + "?redirect_url=" + quote(CONFIG.CALLBACK_URL + quote("?next=/luna/?hostname=" + hostname))
            settings.LOGIN_URL = LOGIN_URL
            self = cls(**initkwargs)
            if hasattr(self, 'get') and not hasattr(self, 'head'):
                self.head = self.get
            self.request = request
            self.args = args
            self.kwargs = kwargs
            return self.dispatch(request, *args, **kwargs)
        view.view_class = cls
        view.view_initkwargs = initkwargs

        # take name and docstring from class
        update_wrapper(view, cls, updated=())

        # and possible attributes set by decorators
        # like csrf_exempt from dispatch
        update_wrapper(view, cls.dispatch, assigned=())
        return view

    def get(self, request, *args, **kwargs):
        from django.http.response import HttpResponseRedirect
        hostname = request.GET.get('hostname', '')
        return HttpResponseRedirect('/luna/?hostname=' + hostname)
```
6. 配置luna单点登录的url路由，修改apps/users/urls/views_urls.py文件，在urlpatterns数组最后增加url路由规则：
```
path('luna-login/', views.login.LunaLoginView.as_view(), name='luna-login'),
```
7. 修改cmdb中jms的luna地址为：https://yourjmsdomain/users/luna-login/
